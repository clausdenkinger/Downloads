$ErrorActionPreference = 'Stop'

Write-Output 'Hello World!'
